"use client"

import Calculator from "../calculator"

export default function SyntheticV0PageForDeployment() {
  return <Calculator />
}