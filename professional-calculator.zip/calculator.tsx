"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const themes = {
  corporate: "bg-gradient-to-br from-blue-600 to-blue-800",
  forest: "bg-gradient-to-br from-green-600 to-green-800",
  royal: "bg-gradient-to-br from-purple-600 to-purple-800",
  sunset: "bg-gradient-to-br from-orange-500 to-orange-700",
  graphite: "bg-gradient-to-br from-gray-600 to-gray-800",
  ruby: "bg-gradient-to-br from-red-600 to-red-800",
}

export default function Calculator() {
  const [display, setDisplay] = useState("0")
  const [theme, setTheme] = useState("corporate")
  const [memory, setMemory] = useState(0)
  const [lastOperation, setLastOperation] = useState("")
  const [newNumber, setNewNumber] = useState(true)

  const handleNumber = (num: string) => {
    if (newNumber) {
      setDisplay(num)
      setNewNumber(false)
    } else {
      setDisplay(display === "0" ? num : display + num)
    }
  }

  const handleOperation = (operation: string) => {
    const current = Number.parseFloat(display)

    switch (lastOperation) {
      case "+":
        setDisplay((memory + current).toString())
        break
      case "-":
        setDisplay((memory - current).toString())
        break
      case "×":
        setDisplay((memory * current).toString())
        break
      case "÷":
        setDisplay((memory / current).toString())
        break
      default:
        break
    }

    setMemory(Number.parseFloat(display))
    setLastOperation(operation)
    setNewNumber(true)
  }

  const handleClear = () => {
    setDisplay("0")
    setMemory(0)
    setLastOperation("")
    setNewNumber(true)
  }

  const handlePercent = () => {
    setDisplay((Number.parseFloat(display) / 100).toString())
  }

  const handleDecimal = () => {
    if (!display.includes(".")) {
      setDisplay(display + ".")
    }
  }

  const handleEquals = () => {
    handleOperation("")
    setLastOperation("")
  }

  return (
    <div className="mx-auto max-w-md p-6">
      <div className={`rounded-lg p-6 shadow-xl ${themes[theme]}`}>
        <div className="mb-4">
          <Select value={theme} onValueChange={setTheme}>
            <SelectTrigger className="w-full bg-white/10 text-white">
              <SelectValue placeholder="Select theme" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="corporate">Corporate Blue</SelectItem>
              <SelectItem value="forest">Forest Green</SelectItem>
              <SelectItem value="royal">Royal Purple</SelectItem>
              <SelectItem value="sunset">Sunset Orange</SelectItem>
              <SelectItem value="graphite">Graphite Gray</SelectItem>
              <SelectItem value="ruby">Ruby Red</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="mb-4 rounded-lg bg-white/10 p-4">
          <div className="text-right text-3xl font-bold text-white">{display}</div>
        </div>

        <div className="grid grid-cols-4 gap-2">
          <Button variant="secondary" className="bg-white/20 text-white hover:bg-white/30" onClick={handleClear}>
            C
          </Button>
          <Button
            variant="secondary"
            className="bg-white/20 text-white hover:bg-white/30"
            onClick={() => setDisplay((Number.parseFloat(display) * -1).toString())}
          >
            +/-
          </Button>
          <Button variant="secondary" className="bg-white/20 text-white hover:bg-white/30" onClick={handlePercent}>
            %
          </Button>
          <Button
            variant="secondary"
            className="bg-white/20 text-white hover:bg-white/30"
            onClick={() => handleOperation("÷")}
          >
            ÷
          </Button>

          {[7, 8, 9].map((num) => (
            <Button
              key={num}
              variant="secondary"
              className="bg-white/10 text-white hover:bg-white/20"
              onClick={() => handleNumber(num.toString())}
            >
              {num}
            </Button>
          ))}
          <Button
            variant="secondary"
            className="bg-white/20 text-white hover:bg-white/30"
            onClick={() => handleOperation("×")}
          >
            ×
          </Button>

          {[4, 5, 6].map((num) => (
            <Button
              key={num}
              variant="secondary"
              className="bg-white/10 text-white hover:bg-white/20"
              onClick={() => handleNumber(num.toString())}
            >
              {num}
            </Button>
          ))}
          <Button
            variant="secondary"
            className="bg-white/20 text-white hover:bg-white/30"
            onClick={() => handleOperation("-")}
          >
            -
          </Button>

          {[1, 2, 3].map((num) => (
            <Button
              key={num}
              variant="secondary"
              className="bg-white/10 text-white hover:bg-white/20"
              onClick={() => handleNumber(num.toString())}
            >
              {num}
            </Button>
          ))}
          <Button
            variant="secondary"
            className="bg-white/20 text-white hover:bg-white/30"
            onClick={() => handleOperation("+")}
          >
            +
          </Button>

          <Button
            variant="secondary"
            className="col-span-2 bg-white/10 text-white hover:bg-white/20"
            onClick={() => handleNumber("0")}
          >
            0
          </Button>
          <Button variant="secondary" className="bg-white/10 text-white hover:bg-white/20" onClick={handleDecimal}>
            .
          </Button>
          <Button variant="secondary" className="bg-white/20 text-white hover:bg-white/30" onClick={handleEquals}>
            =
          </Button>
        </div>
      </div>
    </div>
  )
}

